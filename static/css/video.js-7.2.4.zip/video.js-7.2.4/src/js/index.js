import videojs from './video';
import '@videojs/http-streaming';
export default videojs;
